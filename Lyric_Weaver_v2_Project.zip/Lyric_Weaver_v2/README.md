# Lyric Weaver v2.0

進階多語言歌詞產生器，支援中文、英文、日文、台語混合輸出。

## 功能

- 多語言混合歌詞生成
- 歌曲主題、風格、情緒設定
- 歌曲結構選擇：短版、標準版、完整版
- 自動產生 Suno / Udio Prompt
- 複製歌詞、下載 TXT
- localStorage 儲存作品
- 深色 / 淺色主題切換

## 使用方式

1. 解壓縮 ZIP。
2. 開啟 `index.html`。
3. 輸入主題並選擇語言。
4. 點擊「生成歌詞」。

## 檔案結構

```text
Lyric_Weaver_v2/
├── index.html
├── css/
│   └── style.css
├── js/
│   └── app.js
├── data/
│   └── lyrics.json
├── assets/
└── README.md
```

## 注意

此版本為純前端專案，不需要後端伺服器。
Tailwind CSS 使用 CDN，因此需要網路才能載入 Tailwind 樣式。
