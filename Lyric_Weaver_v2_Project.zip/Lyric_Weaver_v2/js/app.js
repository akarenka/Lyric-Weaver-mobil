const lyricData = {
  "zh": {
    "verse": [
      "微風吹過那條熟悉的{theme}街道",
      "看著天空，心跳似乎停了幾拍",
      "我們曾經約定過，要在這裡相遇",
      "指尖還留著，關於你的氣息",
      "霓虹閃爍，照亮沉默的海岸",
      "我把願望藏進月光裡慢慢發亮"
    ],
    "preChorus": [
      "可是時間不等人，慢慢變成了回憶",
      "能不能回到過去，那個最單純的自己"
    ],
    "chorus": [
      "就在這{theme}的夜晚，我想起你的臉龐",
      "淚水在眼眶裡打轉，卻找不到方向",
      "愛你是場夢，醒來後只剩孤單",
      "但我依然在這裡，守護著這份承諾"
    ],
    "bridge": [
      "或許距離才是真正的答案",
      "不需要言語，也能感受到你的存在"
    ],
    "outro": [
      "隨風散去吧，這段{theme}的旋律..."
    ]
  },
  "en": {
    "verse": [
      "Walking down the road, thinking of {theme}",
      "The sky is turning grey, just like my heart",
      "Do you remember the promises we made?",
      "The scent of you still lingers in the air",
      "City lights are glowing through the rain",
      "I keep your name like a spark inside my veins"
    ],
    "preChorus": [
      "Time is slipping away, memories are fading out",
      "I wish I could go back, before it all fell apart"
    ],
    "chorus": [
      "In this {theme} night, I'm calling out your name",
      "Tears falling down, nothing feels the same",
      "Love is a game, and I've lost my way",
      "But I'll keep holding on, until the end of the day"
    ],
    "bridge": [
      "Maybe distance is the only answer now",
      "No need for words, I feel your soul anyhow"
    ],
    "outro": [
      "Let it fade away, this melody of {theme}..."
    ]
  },
  "ja": {
    "verse": [
      "{theme}の風が吹く、懐かしい通りで",
      "空を見上げて、鼓動が止まる気がして",
      "約束した場所、まだ覚えているかな",
      "指先に残る、あなたの残り香",
      "夜のネオンが雨に溶けていく",
      "小さな願いを月に預けた"
    ],
    "preChorus": [
      "時間は過ぎて、思い出は薄れていく",
      "あの頃に戻れたら、なんて願ってみたり"
    ],
    "chorus": [
      "{theme}の夜空の下、あなたの顔を想う",
      "涙が溢れて、どこへ行けばいいのか",
      "愛は夢の中、一人ぼっちになって",
      "それでも私はここで、ずっと待っているから"
    ],
    "bridge": [
      "距離こそが答えだと、気づいたの",
      "言葉はいらない、ただ心で繋がっている"
    ],
    "outro": [
      "風に消えてゆく、{theme}のメロディ..."
    ]
  },
  "tw": {
    "verse": [
      "風吹過咱熟識的{theme}舊路",
      "看著天頂，心跳親像袂穩定",
      "咱當初約定，要在這相見",
      "指尖猶閣有，關於你的氣味",
      "霓虹燈閃閃爍，照著雨中的心晟",
      "我將願望藏佇月娘光內底"
    ],
    "preChorus": [
      "時間袂等人，慢慢變做回憶",
      "敢會使轉去過去，彼個單純的家己"
    ],
    "chorus": [
      "佇這個{theme}的暗暝，我想起你的面容",
      "目屎佇目箍邊打轉，卻揣袂著方向",
      "愛你是場夢，醒來後只賰孤單",
      "但我猶閣佇遮，守護著這份承諾"
    ],
    "bridge": [
      "或許距離才是真正的答案",
      "毋免講話，也感覺著你的存在"
    ],
    "outro": [
      "隨風散去吧，這段{theme}的旋律..."
    ]
  }
};

const $ = (id) => document.getElementById(id);
const STORAGE_KEY = "lyricWeaverV2Saved";

function pick(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function getLangs() {
  return Array.from(document.querySelectorAll("#langCheckboxGroup input:checked")).map(cb => cb.value);
}

function langBlock(langs, part) {
  const lang = pick(langs);
  return lyricData[lang][part];
}

function buildSections(structure, langs) {
  const standard = [
    ["[Verse 1]", langBlock(langs, "verse").slice(0, 2)],
    ["[Verse 2]", langBlock(langs, "verse").slice(2, 4)],
    ["[Pre-Chorus]", langBlock(langs, "preChorus")],
    ["[Chorus]", langBlock(langs, "chorus")],
    ["[Bridge]", langBlock(langs, "bridge")],
    ["[Final Chorus]", langBlock(langs, "chorus")],
    ["[Outro]", langBlock(langs, "outro")]
  ];

  const short = [
    ["[Verse]", langBlock(langs, "verse").slice(0, 3)],
    ["[Chorus]", langBlock(langs, "chorus")],
    ["[Outro]", langBlock(langs, "outro")]
  ];

  const long = [
    ["[Verse 1]", langBlock(langs, "verse").slice(0, 2)],
    ["[Verse 2]", langBlock(langs, "verse").slice(2, 4)],
    ["[Verse 3]", langBlock(langs, "verse").slice(4, 6)],
    ["[Pre-Chorus]", langBlock(langs, "preChorus")],
    ["[Chorus]", langBlock(langs, "chorus")],
    ["[Bridge]", langBlock(langs, "bridge")],
    ["[Final Chorus]", langBlock(langs, "chorus")],
    ["[Outro]", langBlock(langs, "outro")]
  ];

  return structure === "short" ? short : structure === "long" ? long : standard;
}

function generateLyrics() {
  const theme = $("themeInput").value.trim() || "夢";
  const style = $("styleInput").value;
  const mood = $("moodInput").value;
  const structure = $("structureInput").value;
  const langs = getLangs();

  if (langs.length === 0) {
    alert("請至少選擇一種語言！");
    return;
  }

  const sections = buildSections(structure, langs);
  let lyrics = `Title: ${theme} Melody\nStyle: ${style}\nMood: ${mood}\n\n`;

  sections.forEach(([title, lines]) => {
    lyrics += title + "\n" + lines.join("\n") + "\n\n";
  });

  lyrics = lyrics.replaceAll("{theme}", theme);
  $("lyricOutput").textContent = lyrics;

  const prompt = `Create a ${style} song with ${mood} mood. Theme: ${theme}. Languages: ${langs.join(", ")}. Structure: ${structure}. Keep emotional, melodic, and suitable for vocal performance.`;
  $("promptOutput").value = prompt;

  $("resultArea").classList.remove("hidden");
  $("resultArea").scrollIntoView({ behavior: "smooth", block: "start" });
  toast("歌詞已生成");
}

function copyText(text, message) {
  navigator.clipboard.writeText(text).then(() => toast(message));
}

function downloadLyrics() {
  const text = $("lyricOutput").textContent;
  if (!text.trim()) return toast("沒有可下載的歌詞");
  const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "lyrics-weaver-v2.txt";
  a.click();
  URL.revokeObjectURL(url);
  toast("TXT 已下載");
}

function saveLyrics() {
  const text = $("lyricOutput").textContent;
  if (!text.trim()) return toast("沒有可儲存的歌詞");

  const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  saved.unshift({
    id: Date.now(),
    title: ($("themeInput").value.trim() || "夢") + " Melody",
    text,
    createdAt: new Date().toLocaleString()
  });
  localStorage.setItem(STORAGE_KEY, JSON.stringify(saved.slice(0, 8)));
  renderSavedList();
  toast("作品已儲存");
}

function renderSavedList() {
  const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  const list = $("savedList");
  if (!saved.length) {
    list.innerHTML = `<p class="text-slate-500">尚未儲存作品。</p>`;
    return;
  }

  list.innerHTML = saved.map(item => `
    <button class="w-full text-left p-3 rounded-xl bg-slate-800/60 hover:bg-slate-700/70 border border-slate-700" data-id="${item.id}">
      <strong>${escapeHtml(item.title)}</strong><br>
      <span class="text-xs text-slate-400">${escapeHtml(item.createdAt)}</span>
    </button>
  `).join("");

  list.querySelectorAll("button").forEach(btn => {
    btn.addEventListener("click", () => {
      const item = saved.find(x => String(x.id) === btn.dataset.id);
      $("lyricOutput").textContent = item.text;
      $("resultArea").classList.remove("hidden");
      toast("已載入儲存作品");
    });
  });
}

function clearAll() {
  $("themeInput").value = "";
  $("lyricOutput").textContent = "";
  $("promptOutput").value = "";
  $("resultArea").classList.add("hidden");
  toast("已清除畫面");
}

function toggleTheme() {
  document.body.classList.toggle("light");
  localStorage.setItem("lyricWeaverTheme", document.body.classList.contains("light") ? "light" : "dark");
  toast("主題已切換");
}

function toast(message) {
  const el = $("toast");
  el.textContent = message;
  el.classList.remove("hidden");
  setTimeout(() => el.classList.add("hidden"), 1800);
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, s => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  }[s]));
}

document.addEventListener("DOMContentLoaded", () => {
  $("generateBtn").addEventListener("click", generateLyrics);
  $("clearBtn").addEventListener("click", clearAll);
  $("themeBtn").addEventListener("click", toggleTheme);
  $("copyBtn").addEventListener("click", () => copyText($("lyricOutput").textContent, "歌詞已複製"));
  $("copyPromptBtn").addEventListener("click", () => copyText($("promptOutput").value, "Prompt 已複製"));
  $("downloadBtn").addEventListener("click", downloadLyrics);
  $("saveBtn").addEventListener("click", saveLyrics);

  if (localStorage.getItem("lyricWeaverTheme") === "light") {
    document.body.classList.add("light");
  }

  renderSavedList();
});
